## ------------------------------------------------------------------------
a = 3.14159265 
b = "ISDS Workshop" 
c = TRUE

## ------------------------------------------------------------------------
a
b
c

## ------------------------------------------------------------------------
a = c(1,2,-5,3.6)
b = c("ISDS","Workshop")
c = c(TRUE, FALSE, TRUE)

## ------------------------------------------------------------------------
length(a)
length(b)
length(c)

## ------------------------------------------------------------------------
1:10
5:-2
seq(2,23,by=3)

## ------------------------------------------------------------------------
rep(1:4, times = 2)
rep(1:4, each  = 2)
rep(1:4, each  = 2, times = 2)

## ------------------------------------------------------------------------
a = c("one","two","three","four","five")
a[2:4]
a[c(3,5)]
a[rep(3,4)]

## ------------------------------------------------------------------------
a[c(TRUE, TRUE, FALSE, FALSE, FALSE)]

## ------------------------------------------------------------------------
a[-1]

## ------------------------------------------------------------------------
m1 = cbind(c(1,2), c(3,4))       # Row bind
m2 = rbind(c(1,3), c(2,4))       # Column bind
all.equal(m1, m2)
m3 = matrix(1:4, nrow=2, ncol=2)
all.equal(m1,m3)
m4 = matrix(1:4, nrow=2, ncol=2, byrow=TRUE)
all.equal(m3, m4)
m3
m4

## ------------------------------------------------------------------------
m = matrix(1:12, nrow=3, ncol=4)
m
m[2,3]

## ------------------------------------------------------------------------
m[1:2,3:4]

## ------------------------------------------------------------------------
m[1:2,]

## ------------------------------------------------------------------------
m[-c(3,4),]

## ------------------------------------------------------------------------
m[1:2]

## ------------------------------------------------------------------------
c(1,"a")

## ------------------------------------------------------------------------
c(TRUE, 1, FALSE)

## ------------------------------------------------------------------------
c(TRUE, 1, "a")

## ------------------------------------------------------------------------
m = rbind(c(1, 12, 8, 6),
          c(4, 10, 2, 9),
          c(11, 3, 5, 7))
m

## ----, echo=FALSE--------------------------------------------------------
# Reconstruct the matrix 

# Print the element in the 3rd-row and 4th column

# Print the 2nd column

# Print all but the 3rd row

## ----, echo=FALSE--------------------------------------------------------
library(ISDSWorkshop)
workshop(write_scripts=FALSE, launch_index=FALSE)

## ------------------------------------------------------------------------
GI = read.csv("GI.csv")
dim(GI)

## ----, eval=FALSE--------------------------------------------------------
#  workshop(write_scripts=FALSE, launch_index=FALSE)

## ------------------------------------------------------------------------
GI[1:2, 3:4]

## ------------------------------------------------------------------------
GI[1:2, c("facility","icd9","gender")]

## ------------------------------------------------------------------------
str(GI)

## ------------------------------------------------------------------------
nlevels(GI$gender)
levels(GI$gender)
GI$gender[1:3]
as.numeric(GI$gender[1:3])

## ------------------------------------------------------------------------
GI$facility = as.factor(GI$facility)
head(table(GI$facility))

## ------------------------------------------------------------------------
head(as.character(GI$facility))             # This returns the levels as a character vector
head(as.numeric(GI$facility))               # This returns the numeric encoding
head(as.numeric(as.character(GI$facility))) # This returns the original numeric factor levels

## ------------------------------------------------------------------------
GI$ageC = cut(GI$age, c(-Inf, 5, 18, 45 ,60, Inf))
head(table(GI$ageC))

## ------------------------------------------------------------------------
GI$date = as.Date(GI$date)
str(GI$date)

## ----, eval=FALSE--------------------------------------------------------
#  ?as.Date

## ----, eval=FALSE--------------------------------------------------------
#  as.Date("12/09/14", format="%m/%d/%y")

## ----, echo=FALSE--------------------------------------------------------
# Create icd9code

# Find the icd9code that is most numerous

## ----, echo=FALSE--------------------------------------------------------
d = data.frame(week=1:3, GI=c(246,195,212), ILI=c(948, 1020, 1024))
d

## ----, echo=FALSE--------------------------------------------------------
library(reshape2)
melt(d, id.vars="week", variable.name="syndrome", value.name="count")

## ------------------------------------------------------------------------
library(reshape2)

## ------------------------------------------------------------------------
d = data.frame(week=1:3, GI=c(246,195,212), ILI=c(948, 1020, 1024))

## ------------------------------------------------------------------------
m = melt(d, id.vars    = "week",     # The variables you want to remain on the columns
         variable.name = "syndrome", # The name for the variable column
         value.name    = "count")    # The name for the response column
m

## ------------------------------------------------------------------------
dcast(m, week ~ syndrome) # Notice that we do not use the count (value) column at all

## ------------------------------------------------------------------------
library(plyr)

## ------------------------------------------------------------------------
ddply(m,                  # We need to use the melted version of the data set
      .(syndrome),        # Do the following for each syndrome
      summarize,          # Summarize 
      total = sum(count)) # Calculate `total` which is the sum of count for each syndrome

## ------------------------------------------------------------------------
GI$date = as.Date(GI$date) # Make sure the dates are actually dates
GI$week = cut(GI$date, 
              breaks="weeks", 
              start.on.monday=TRUE) 

## ------------------------------------------------------------------------
GI_count = ddply(GI, 
                 .(week, gender, ageC),
                 summarize,
                 total = length(id))    # Count the number of lines in each week-gender-ageC combination
GI_count

## ----, echo=FALSE--------------------------------------------------------
# Aggregate our GI data set by gender, ageC, and icd9code (the ones created in the last activity).

## ------------------------------------------------------------------------
library(ggplot2)

## ----, eval=FALSE, echo=FALSE--------------------------------------------
#  qplot(data=GI, x=age, geom="histogram", binwidth=1)

## ------------------------------------------------------------------------
ggplot(GI, aes(x = age)) + geom_histogram(binwidth=1)

## ------------------------------------------------------------------------
ggplot(GI, aes(x = 1, y = age)) + geom_boxplot()

## ------------------------------------------------------------------------
ggplot(GI, aes(x = facility, y = age)) + geom_boxplot()

## ------------------------------------------------------------------------
ggplot(GI, aes(x=date, y=age)) + geom_point()

## ------------------------------------------------------------------------
ggplot(GI, aes(x=facility)) + geom_bar()

## ----, echo=FALSE--------------------------------------------------------
# Construct a histogram for age at facility 37.

# Construct a boxplot for age at facility 37. 

## ----, echo=FALSE--------------------------------------------------------
# Construct a bar chart for the first three digits of zipcode at facility 37.

## ------------------------------------------------------------------------
ggplot(GI, aes(x = age)) + geom_histogram(binwidth=1, color='red',   fill='blue')
ggplot(GI, aes(x = age)) + geom_histogram(binwidth=1, color='white', fill='orange')

## ------------------------------------------------------------------------
ggplot(GI, aes(x=date, y=age)) + geom_point(color='purple')

## ------------------------------------------------------------------------
ggplot(GI, aes(x = facility, y = age)) + 
  geom_boxplot() + 
  labs(x='Facility ID', y='Age (in years)', title='Age by Facility ID')

## ------------------------------------------------------------------------
ggplot(GI, aes(x=date, y=age)) + geom_point(shape=2, color='red')

## ----, eval=FALSE--------------------------------------------------------
#  ?points

## ------------------------------------------------------------------------
g = ggplot(ddply(GI, .(week), summarize, count=length(id)),
       aes(x=as.numeric(week), y=count)) +
  labs(x='Week #', y='Weekly count')

g + geom_line()
g + geom_line(size=2, color='firebrick', linetype=2)

## ------------------------------------------------------------------------
g = g+geom_line(size=1, color='firebrick')
g + theme_bw()

## ----, eval=FALSE--------------------------------------------------------
#  ?theme
#  ?theme_bw

## ----, eval=FALSE--------------------------------------------------------
#  ?ggplot
#  ?geom_point


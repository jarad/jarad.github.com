## ----, eval=FALSE--------------------------------------------------------
#  help.start()

## ----, eval=FALSE--------------------------------------------------------
#  >

## ----, eval=FALSE--------------------------------------------------------
#  help()

## ----, eval=FALSE--------------------------------------------------------
#  hepl()
#  help() # Use up arrow and fix

## ------------------------------------------------------------------------
a = 1 
b = 2
a+b

## ------------------------------------------------------------------------
x = 1:10
y = rep(c(1,2), each=5)
m = lm(y~x)
s = summary(m)

## ----, eval=FALSE--------------------------------------------------------
#  x
#  y
#  m
#  s
#  s$r.squared

## ------------------------------------------------------------------------
1+2
1-2
1/2
1*2

## ------------------------------------------------------------------------
(1+3)*2+100^2 # standard order of operations
sin(2*pi)
sqrt(4)
10^2
log(10)
log(10,base=10)

## ------------------------------------------------------------------------
a = 1
b = 2
a+b
a-b
a/b
a*b

## ------------------------------------------------------------------------
population = 1000
number_infected = 200
deaths = 3

death_rate = deaths / number_infected
attack_rate = number_infected / population

death_rate
attack_rate

## ----, echo=FALSE--------------------------------------------------------
# Find the probability the individual has the disease if 
# specificity is 0.99, sensitivity is 0.95, and prevalence is 0.001

## ----, eval=FALSE--------------------------------------------------------
#  setwd(choose.dir(getwd()))

## ----, eval=FALSE--------------------------------------------------------
#  install.packages("ISDSWorkshop")

## ------------------------------------------------------------------------
library(ISDSWorkshop)

## ----, warning=FALSE-----------------------------------------------------
workshop()

## ------------------------------------------------------------------------
# This is just a comment. 
1+1 # So is this
# 1+2

## ------------------------------------------------------------------------
GI = read.csv("GI.csv")

## ----, tidy=FALSE--------------------------------------------------------
GI2 = read.table("GI.csv", 
                 header=TRUE, # There is a header.
                 sep=",")     # The column delimiter is a comma.

## ------------------------------------------------------------------------
all.equal(GI, GI2)

## ------------------------------------------------------------------------
dim(GI)
names(GI)
head(GI)
tail(GI)

## ----, eval=FALSE--------------------------------------------------------
#  d = read.xlsx("filename.xlsx", sheetIndex=1)

## ----, eval=FALSE--------------------------------------------------------
#  d = read.xlsx("filename.xlsx", sheetName="sheetName")

## ----, eval=FALSE, tidy=FALSE--------------------------------------------
#  d = read.table("filename.csv", # Make sure to change filename>to your filename and
#                                 # make sure you use the extension, e.g. .csv.
#                 header = TRUE,  # If there is no header column, change TRUE to FALSE.
#                 sep =",",       # The column delimiter is a comma.
#                 skip = 0        # Skip this many lines before starting to read the file
#                 )

## ----, echo=FALSE--------------------------------------------------------
# Read in the csv file

## ----, echo=FALSE--------------------------------------------------------
# Read in the txt file directly from its URL

## ------------------------------------------------------------------------
summary(GI)

## ----, eval=FALSE--------------------------------------------------------
#  GI$age
#  GI[,5] # Since age is the 5th column

## ------------------------------------------------------------------------
min(GI$age)
max(GI$age)
mean(GI$age)
median(GI$age)
quantile(GI$age, c(.025,.25,.5,.75,.975))

## ------------------------------------------------------------------------
table(GI$facility)

## ------------------------------------------------------------------------
GI_37 = subset(GI, facility==37)
nrow(GI_37) # Number of rows (observations) in the new data set

## ------------------------------------------------------------------------
GI_AbdPain = subset(GI, chief_complaint == "Abd Pain")
nrow(GI_AbdPain)

## ------------------------------------------------------------------------
GI_37a = GI[GI$facility==37,]
all.equal(GI_37, GI_37a)
GI_AbdPain1 = GI[GI$chief_complaint == "Abd Pain",]
all.equal(GI_AbdPain, GI_AbdPain1)

## ----, eval=FALSE--------------------------------------------------------
#  subset(GI, age <   5)
#  subset(GI, age >= 60)
#  subset(GI, chief_complaint %in% c("Abd Pain","ABD PAIN"))
#  subset(GI, !(facility %in% c(37,66))) # facility is NOT 37 or 66

## ------------------------------------------------------------------------
summary(GI_37$age)
summary(GI_AbdPain$age)

## ----, echo=FALSE--------------------------------------------------------
# Find the min, max, mean, and median age for zipcode 20032.

## ------------------------------------------------------------------------
hist(GI$age)

## ------------------------------------------------------------------------
hist(GI$age, 50)

## ------------------------------------------------------------------------
hist(GI$age, 0:158)

## ------------------------------------------------------------------------
boxplot(GI$age)

## ------------------------------------------------------------------------
boxplot(age~facility, GI, xlab="Facility", ylab="Age")

## ------------------------------------------------------------------------
GI$date = as.Date(GI$date)
plot(age~date, GI)

## ------------------------------------------------------------------------
counts = table(GI$facility)
barplot(counts, xlab="Facility", ylab="Count", main="Number of observations at each facility")

## ----, echo=FALSE--------------------------------------------------------
# Construct a histogram for age at facility 37.

# Construct a boxplot for age at facility 37. 

## ----, echo=FALSE--------------------------------------------------------
# Construct a bar chart for the zipcode at facility 37.

## ----, echo=FALSE--------------------------------------------------------
?mean

## ----, echo=FALSE--------------------------------------------------------
help.search("mean")


## ----, eval=FALSE--------------------------------------------------------
#  setwd(choose.dir())

## ------------------------------------------------------------------------
library(ISDSWorkshop)
workshop(launch_index  = FALSE)

## ------------------------------------------------------------------------
# Pretend this is the top of the script
library(plyr)
library(ggplot2)
library(gridExtra)

## ------------------------------------------------------------------------
# Read in csv files
GI = read.csv('GI.csv')
icd9df = read.csv("icd9.csv")

# Mutate data.frame
GI = mutate(GI,
            date      = as.Date(date),
            weekC     = cut(date, breaks="weeks"),
            week      = as.numeric(weekC),
            facility  = as.factor(facility),
            icd9class = factor(cut(icd9, 
                            breaks = icd9df$code_cutpoint, 
                            labels = icd9df$classification[-nrow(icd9df)], 
                            right  = TRUE)),
            ageC      = cut(age, 
                            breaks = c(-Inf, 5, 18, 45 ,60, Inf)),
            zip3      = trunc(zipcode/100))

## ----, eval=FALSE--------------------------------------------------------
#  source("read_data.R")

## ------------------------------------------------------------------------
dim(GI)
str(GI)
summary(GI)

## ----, echo=FALSE--------------------------------------------------------
# Create weekD variable in GI data set

## ------------------------------------------------------------------------
GI_wf = ddply(GI, .(week, facility), summarize, count = length(id))

## ----, eval=FALSE--------------------------------------------------------
#  nrow(GI_wf) # Should have number of weeks times number of facilities rows
#  ncol(GI_wf) # Should have 3 columns: week, facility, count
#  dim(GI_wf)
#  head(GI_wf)
#  tail(GI_wf)
#  summary(GI_wf)
#  summary(GI_wf$facility)

## ------------------------------------------------------------------------
ggplot(GI_wf, aes(x=week, y=count)) + geom_point()

## ------------------------------------------------------------------------
ggplot(GI_wf, aes(x=week, y=count, color=facility)) + geom_point()

## ------------------------------------------------------------------------
ggplot(GI_wf, aes(x=week, y=count, shape=facility)) + geom_point()

## ----, echo=FALSE--------------------------------------------------------
# Construct a data set aggregated by week and age category

# Construct a plot to look at weekly GI cases by age category.

## ------------------------------------------------------------------------
ggplot(GI_wf, aes(x=week, y=count)) + geom_point() + facet_wrap(~facility)

## ------------------------------------------------------------------------
ggplot(GI_wf, aes(x=week, y=count)) + geom_point() + facet_wrap(~facility, scales="free")

## ------------------------------------------------------------------------
GI_sa = ddply(GI, .(week, gender, ageC), summarize, count = length(id))

## ------------------------------------------------------------------------
ggplot(GI_sa, aes(x=week, y=count)) + geom_point() + facet_grid(gender~ageC)

## ------------------------------------------------------------------------
ggplot(GI_sa, aes(x=week, y=count, shape=gender, color=gender)) + geom_point() + facet_wrap(~ageC)

## ----, echo=FALSE--------------------------------------------------------
# Construct a plot of weekly GI counts by zip3 and ageC. 

## ------------------------------------------------------------------------
IPD = subset(GI, icd9class == "infectious and parasitic disease")
IPD_w = ddply(IPD, .(week), summarize, count=length(id))
ggplot(IPD_w, aes(x=week, y=count)) + geom_point()

## ------------------------------------------------------------------------
conditions = levels(GI$icd9class)
conditions

## ------------------------------------------------------------------------
IPDp = subset(GI, icd9class %in% levels(icd9class)[c(1,3)])
summary(IPDp$icd9class)

## ------------------------------------------------------------------------
IPDp_w = ddply(IPDp, .(week, icd9class), summarize, count = length(id))
ggplot(IPDp_w, aes(x=week, y=count)) + geom_point() + facet_wrap(~icd9class, scales="free")

## ------------------------------------------------------------------------
nIPD = subset(GI, icd9class != "infectious and parasitic disease")
nIPD_w = ddply(nIPD, .(week, icd9class), summarize, count = length(id))
ggplot(nIPD_w, aes(x=week, y=count)) + geom_point() + facet_wrap(~icd9class, scales="free")

## ------------------------------------------------------------------------
nIPDp = subset(GI, !(icd9class %in% levels(icd9class)[c(1,3)]))
nIPDp_w = ddply(nIPDp, .(week, icd9class), summarize, count = length(id))
ggplot(nIPDp_w, aes(x=week, y=count)) + geom_point() + facet_wrap(~icd9class, scales="free")

## ------------------------------------------------------------------------
Age60p = subset(GI, age > 60)
Age60p_w = ddply(Age60p, .(week), summarize, count = length(id))
ggplot(Age60p_w, aes(x=week, y=count)) + geom_point()

## ------------------------------------------------------------------------
Age_lte30 = subset(GI, age <= 30)
Age_lte30_w = ddply(Age_lte30, .(week), summarize, count = length(id))
ggplot(Age_lte30_w, aes(x=week, y=count)) + geom_point()

## ------------------------------------------------------------------------
Age30to60 = subset(GI, age > 30 & age <= 60) # This includes those who are 60, but not those who are 30
Age30to60_w = ddply(Age30to60, .(week), summarize, count = length(id))
ggplot(Age30to60_w, aes(x=week, y=count)) + geom_point()

## ------------------------------------------------------------------------
two_dates = as.Date(c("2007-01-01", "2007-12-31"))

## ------------------------------------------------------------------------
early = subset(GI, date <  two_dates[1])
late  = subset(GI, date >= two_dates[2])
mid   = subset(GI, date >= two_dates[1] & date < two_dates[2])

## ------------------------------------------------------------------------
early_w = ddply(early, .(week), summarize, count = length(id))
late_w  = ddply(late,  .(week), summarize, count = length(id))
mid_w   = ddply(mid,   .(week), summarize, count = length(id))

g1 = ggplot(early_w, aes(x=week, y=count)) + geom_point()
g2 = ggplot(late_w,  aes(x=week, y=count)) + geom_point()
g3 = ggplot(mid_w,   aes(x=week, y=count)) + geom_point()

## ----, eval=FALSE--------------------------------------------------------
#  library(gridExtra)

## ------------------------------------------------------------------------
grid.arrange(g1,g2,g3)

## ----, echo=FALSE--------------------------------------------------------
# Subset the data to zipcode 206xx between Jan 1, 2008 and Dec 31, 2008

# Aggregate the date for each week in this time frame

# Construct the plot of weekly GI counts in zipcode 206xx.

## ------------------------------------------------------------------------
GI$weekD = as.Date(GI$weekC) 
GI_sum = ddply(GI, .(weekD, gender, ageC), summarize, count = length(id))
ggplot(GI_sum, aes(x=weekD, y=count, color=gender)) + geom_point(size=3) + facet_grid(ageC~., scales="free_y")

## ------------------------------------------------------------------------
levels(GI_sum$ageC)
levels(GI_sum$ageC) = paste("Age:", c("<5","5-18","18-45","45-60",">60"))
table(GI_sum$ageC)

## ------------------------------------------------------------------------
g = ggplot(GI_sum, aes(x=weekD, y=count, color=gender)) + geom_point(size=3) + facet_grid(ageC~., scales="free_y")
g

## ------------------------------------------------------------------------
g = g + scale_color_manual(values=c("hotpink","blue"), name='Sex')
g

## ------------------------------------------------------------------------
g = g + labs(title="Weekly GI cases", x="Year", y="Weekly count") 
g

## ------------------------------------------------------------------------
g = g + theme_bw()
g

## ----, eval=FALSE--------------------------------------------------------
#  ?theme_bw

## ------------------------------------------------------------------------
g = g + theme(title=element_text(size=rel(2)),
              text = element_text(size=16),
              legend.background = element_rect(fill="white", size=.5, color="black"))
g

## ------------------------------------------------------------------------
g
ggsave("plot.pdf")

## ------------------------------------------------------------------------
ggsave("plot.pdf", width=14, height=8)


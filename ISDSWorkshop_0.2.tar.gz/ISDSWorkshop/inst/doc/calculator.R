## ----setup, include=FALSE------------------------------------------------
library(knitr)
opts_chunk$set(out.extra='style="display:block; margin: auto"', fig.align="center")

## ------------------------------------------------------------------------
1+1
1-1
4/2
4*2

## ------------------------------------------------------------------------
sqrt(4)
abs(-4)
cos(2*pi)

## ------------------------------------------------------------------------
log(10)
log10(10)
log(10,base=10)
log(10,base=exp(1))

## ------------------------------------------------------------------------
a = 2
b = 3
a*b
b/a
a+b
a-b

## ------------------------------------------------------------------------
number_of_cases = 10

population = 1000

attack_rate = number_of_cases / population

attack_rate

number_of_cases = 20

number_of_cases / population

